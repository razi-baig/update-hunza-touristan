"use client";

import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import { CheckIcon, StarIcon } from "./Icons";

export default function ReviewForm() {
  const router = useRouter();
  const [rating, setRating] = useState(5);
  const [hover, setHover] = useState(0);
  const [status, setStatus] = useState<"idle" | "loading" | "done">("idle");
  const [error, setError] = useState("");

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const data = new FormData(form);
    setStatus("loading");
    setError("");
    try {
      const res = await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: data.get("name"),
          location: data.get("location"),
          comment: data.get("comment"),
          rating,
        }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Something went wrong.");
      form.reset();
      setRating(5);
      setStatus("done");
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
      setStatus("idle");
    }
  }

  return (
    <div className="mt-14 rounded-2xl bg-brand-50 p-6 sm:p-10">
      <div className="grid gap-8 lg:grid-cols-[1fr_1.6fr]">
        <div>
          <h3 className="font-display text-2xl font-semibold">Visited Hunza?</h3>
          <p className="mt-2 text-sm leading-relaxed text-slate-600">
            Share your experience to help future travelers plan their journey.
          </p>
        </div>

        {status === "done" ? (
          <div className="flex items-center gap-3 rounded-xl bg-white p-5 text-sm text-brand-700 shadow-sm">
            <CheckIcon /> Thank you! Your review has been published.
            <button
              type="button"
              className="ml-auto font-semibold underline"
              onClick={() => setStatus("idle")}
            >
              Write another
            </button>
          </div>
        ) : (
          <form onSubmit={onSubmit} className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="r-name" className="field-label">Name</label>
                <input id="r-name" name="name" required minLength={2} maxLength={80} className="field" placeholder="Your name" />
              </div>
              <div>
                <label htmlFor="r-loc" className="field-label">Location (optional)</label>
                <input id="r-loc" name="location" maxLength={80} className="field" placeholder="City, Country" />
              </div>
            </div>
            <div>
              <span className="field-label">Rating</span>
              <div className="flex gap-1 text-accent" onMouseLeave={() => setHover(0)}>
                {[1, 2, 3, 4, 5].map((n) => (
                  <button
                    key={n}
                    type="button"
                    aria-label={`${n} star${n > 1 ? "s" : ""}`}
                    aria-pressed={rating === n}
                    onMouseEnter={() => setHover(n)}
                    onClick={() => setRating(n)}
                    className="rounded p-0.5"
                  >
                    <StarIcon filled={n <= (hover || rating)} width={26} height={26} />
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label htmlFor="r-comment" className="field-label">Your review</label>
              <textarea id="r-comment" name="comment" required minLength={10} maxLength={800} rows={4} className="field" placeholder="Tell us about your trip…" />
            </div>
            {error && <p role="alert" className="text-sm text-red-600">{error}</p>}
            <button type="submit" disabled={status === "loading"} className="btn-primary">
              {status === "loading" ? "Submitting…" : "Submit review"}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
