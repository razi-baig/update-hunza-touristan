"use client";

import { useEffect, useState } from "react";
import { CloseIcon, MenuIcon, MountainIcon } from "./Icons";

const links = [
  { href: "#home", label: "Home" },
  { href: "#places", label: "Popular Places" },
  { href: "#gallery", label: "Gallery" },
  { href: "#reviews", label: "Reviews" },
  { href: "#book", label: "Booking" },
];

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const solid = scrolled || open;

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        solid ? "bg-white/95 shadow-sm backdrop-blur" : "bg-transparent"
      }`}
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5 sm:px-8">
        <a
          href="#home"
          className={`flex items-center gap-2 font-display text-xl font-semibold tracking-tight ${
            solid ? "text-brand-900" : "text-white"
          }`}
        >
          <span className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-600 text-white">
            <MountainIcon width={18} height={18} />
          </span>
          Hunza Touristan
        </a>

        <nav className="hidden items-center gap-8 md:flex" aria-label="Primary">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className={`text-sm font-medium transition hover:text-brand-500 ${
                solid ? "text-slate-700" : "text-white/90"
              }`}
            >
              {l.label}
            </a>
          ))}
          <a href="#book" className="btn-primary !py-2.5">
            Book Now
          </a>
        </nav>

        <button
          type="button"
          className={`rounded-lg p-2 md:hidden ${solid ? "text-ink" : "text-white"}`}
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <CloseIcon width={24} height={24} /> : <MenuIcon width={24} height={24} />}
        </button>
      </div>

      {open && (
        <nav
          className="border-t border-slate-100 bg-white px-5 pb-5 pt-2 md:hidden"
          aria-label="Mobile"
        >
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className="block border-b border-slate-100 py-3 text-base font-medium text-slate-700"
            >
              {l.label}
            </a>
          ))}
          <a
            href="#book"
            onClick={() => setOpen(false)}
            className="btn-primary mt-4 w-full"
          >
            Book Now
          </a>
        </nav>
      )}
    </header>
  );
}
