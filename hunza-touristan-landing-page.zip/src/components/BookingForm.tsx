"use client";

import { useState, type FormEvent } from "react";
import { images, places } from "@/lib/data";
import { CheckIcon } from "./Icons";

type Errors = Record<string, string>;

export default function BookingForm() {
  const [status, setStatus] = useState<"idle" | "loading" | "done">("idle");
  const [error, setError] = useState("");
  const [fieldErrors, setFieldErrors] = useState<Errors>({});

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const d = new FormData(form);
    setStatus("loading");
    setError("");
    setFieldErrors({});
    try {
      const res = await fetch("/api/bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(Object.fromEntries(d.entries())),
      });
      const json = await res.json();
      if (!res.ok) {
        setFieldErrors(json.errors ?? {});
        throw new Error(json.error || "Something went wrong.");
      }
      form.reset();
      setStatus("done");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
      setStatus("idle");
    }
  }

  const fe = (k: string) =>
    fieldErrors[k] ? <p className="mt-1 text-xs text-red-600">{fieldErrors[k]}</p> : null;

  const today = new Date().toISOString().slice(0, 10);

  return (
    <section id="book" className="relative isolate overflow-hidden bg-brand-900 py-24">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={images.night}
        alt=""
        loading="lazy"
        className="absolute inset-0 -z-20 h-full w-full object-cover opacity-30"
      />
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 sm:px-8 lg:grid-cols-[1fr_1.2fr]">
        <div className="text-white">
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-amber-300">
            Booking
          </p>
          <h2 className="mt-3 font-display text-3xl font-semibold leading-tight sm:text-4xl md:text-[2.6rem]">
            Start planning your Hunza journey
          </h2>
          <p className="mt-4 max-w-md leading-relaxed text-white/80">
            Tell us where you&apos;d like to go and when. Our team will get back to you within
            24 hours with a tailored itinerary and pricing.
          </p>
          <ul className="mt-8 space-y-3 text-sm text-white/90">
            {[
              "Local, experienced guides",
              "Flexible, customizable itineraries",
              "Free to enquire — no payment required",
            ].map((t) => (
              <li key={t} className="flex items-center gap-3">
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-brand-500">
                  <CheckIcon width={14} height={14} />
                </span>
                {t}
              </li>
            ))}
          </ul>
        </div>

        <div className="rounded-3xl bg-white p-6 shadow-2xl sm:p-9">
          {status === "done" ? (
            <div className="py-10 text-center">
              <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-brand-100 text-brand-600">
                <CheckIcon width={32} height={32} />
              </span>
              <h3 className="mt-5 font-display text-2xl font-semibold">Request received</h3>
              <p className="mx-auto mt-2 max-w-sm text-sm text-slate-600">
                Thank you! We&apos;ll contact you shortly by email to confirm the details of your
                trip.
              </p>
              <button type="button" className="btn-primary mt-6" onClick={() => setStatus("idle")}>
                Make another booking
              </button>
            </div>
          ) : (
            <form onSubmit={onSubmit} noValidate className="space-y-4">
              <h3 className="font-display text-2xl font-semibold">Booking request</h3>
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label htmlFor="b-name" className="field-label">Full name</label>
                  <input id="b-name" name="name" required className="field" placeholder="Jane Doe" autoComplete="name" />
                  {fe("name")}
                </div>
                <div>
                  <label htmlFor="b-email" className="field-label">Email</label>
                  <input id="b-email" name="email" type="email" required className="field" placeholder="jane@example.com" autoComplete="email" />
                  {fe("email")}
                </div>
                <div>
                  <label htmlFor="b-phone" className="field-label">Phone</label>
                  <input id="b-phone" name="phone" type="tel" required className="field" placeholder="+92 300 0000000" autoComplete="tel" />
                  {fe("phone")}
                </div>
                <div>
                  <label htmlFor="b-dest" className="field-label">Destination</label>
                  <select id="b-dest" name="destination" required defaultValue="" className="field">
                    <option value="" disabled>Select a destination</option>
                    {places.map((p) => (
                      <option key={p.id} value={p.name}>{p.name}</option>
                    ))}
                    <option value="Attabad Lake">Attabad Lake</option>
                    <option value="Passu Cones">Passu Cones</option>
                    <option value="Full Hunza tour">Full Hunza tour</option>
                  </select>
                  {fe("destination")}
                </div>
                <div>
                  <label htmlFor="b-trav" className="field-label">Travelers</label>
                  <input id="b-trav" name="travelers" type="number" min={1} max={50} defaultValue={2} required className="field" />
                  {fe("travelers")}
                </div>
                <div>
                  <label htmlFor="b-date" className="field-label">Travel date</label>
                  <input id="b-date" name="travelDate" type="date" min={today} className="field" />
                  {fe("travelDate")}
                </div>
              </div>
              <div>
                <label htmlFor="b-msg" className="field-label">Message (optional)</label>
                <textarea id="b-msg" name="message" rows={4} maxLength={2000} className="field" placeholder="Tell us about your interests, budget or special requests…" />
                {fe("message")}
              </div>
              {error && <p role="alert" className="rounded-lg bg-red-50 px-4 py-3 text-sm text-red-700">{error}</p>}
              <button type="submit" disabled={status === "loading"} className="btn-primary w-full !py-3.5">
                {status === "loading" ? "Sending…" : "Send booking request"}
              </button>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}
