import { places } from "@/lib/data";
import { ArrowRightIcon } from "./Icons";

export default function Places() {
  return (
    <section id="places" className="mx-auto max-w-7xl px-5 py-24 sm:px-8">
      <div className="max-w-2xl">
        <p className="section-eyebrow">Destinations</p>
        <h2 className="section-title">Popular places to visit</h2>
        <p className="mt-4 text-slate-600">
          From hilltop viewpoints to Silk Road villages, these are the places every
          visitor to Hunza should see.
        </p>
      </div>

      <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-6">
        {places.map((p, i) => (
          <article
            key={p.id}
            className={`group overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-xl ${
              i < 2 ? "lg:col-span-3" : "lg:col-span-2"
            }`}
          >
            <div className="relative overflow-hidden">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={p.image}
                alt={p.name}
                loading="lazy"
                className={`w-full object-cover transition duration-700 group-hover:scale-105 ${
                  i < 2 ? "h-72" : "h-56"
                }`}
              />
              <span className="absolute left-4 top-4 rounded-full bg-white/90 px-3 py-1 text-xs font-semibold text-brand-700 backdrop-blur">
                {p.tag}
              </span>
            </div>
            <div className="p-6">
              <h3 className="font-display text-xl font-semibold">{p.name}</h3>
              <p className="mt-3 text-sm leading-relaxed text-slate-600">{p.description}</p>
              <a
                href="#book"
                className="mt-5 inline-flex items-center gap-1.5 text-sm font-semibold text-brand-600 transition hover:gap-2.5"
              >
                Plan a visit <ArrowRightIcon width={16} height={16} />
              </a>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
