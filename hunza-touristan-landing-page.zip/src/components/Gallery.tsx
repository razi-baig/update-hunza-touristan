"use client";

import { useCallback, useEffect, useState } from "react";
import { gallery } from "@/lib/data";
import { CloseIcon } from "./Icons";

export default function Gallery() {
  const [active, setActive] = useState<number | null>(null);

  const close = useCallback(() => setActive(null), []);

  useEffect(() => {
    if (active === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
      if (e.key === "ArrowRight") setActive((i) => (i === null ? i : (i + 1) % gallery.length));
      if (e.key === "ArrowLeft")
        setActive((i) => (i === null ? i : (i - 1 + gallery.length) % gallery.length));
    };
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [active, close]);

  const current = active !== null ? gallery[active] : null;

  return (
    <section id="gallery" className="bg-sand py-24">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="max-w-2xl">
          <p className="section-eyebrow">Gallery</p>
          <h2 className="section-title">Hunza through the seasons</h2>
          <p className="mt-4 text-slate-600">
            Every season paints the valley differently. Select a photo to view it larger.
          </p>
        </div>

        <div className="mt-12 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {gallery.map((g, i) => (
            <button
              key={g.title}
              type="button"
              onClick={() => setActive(i)}
              className="group relative aspect-[4/3] overflow-hidden rounded-2xl text-left shadow-sm focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600"
              aria-label={`View ${g.title}`}
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={g.image}
                alt={g.title}
                loading="lazy"
                className="h-full w-full object-cover transition duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-5 text-white">
                <p className="text-xs font-semibold uppercase tracking-widest text-amber-300">
                  {g.season}
                </p>
                <h3 className="mt-1 font-display text-xl font-semibold">{g.title}</h3>
              </div>
            </button>
          ))}
        </div>
      </div>

      {current && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={current.title}
          className="fixed inset-0 z-[60] flex items-center justify-center bg-black/85 p-4"
          onClick={close}
        >
          <button
            type="button"
            aria-label="Close"
            onClick={close}
            className="absolute right-4 top-4 rounded-full bg-white/10 p-2 text-white transition hover:bg-white/20"
          >
            <CloseIcon width={24} height={24} />
          </button>
          <figure
            className="max-h-full w-full max-w-4xl overflow-hidden rounded-2xl bg-white"
            onClick={(e) => e.stopPropagation()}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={current.image.replace("w=1200&h=800", "w=1600&h=1000")}
              alt={current.title}
              className="max-h-[65vh] w-full object-cover"
            />
            <figcaption className="p-6">
              <p className="text-xs font-semibold uppercase tracking-widest text-brand-600">
                {current.season}
              </p>
              <h3 className="mt-1 font-display text-2xl font-semibold">{current.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-slate-600">{current.description}</p>
            </figcaption>
          </figure>
        </div>
      )}
    </section>
  );
}
