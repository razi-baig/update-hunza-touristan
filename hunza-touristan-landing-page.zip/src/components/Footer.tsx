import {
  FacebookIcon,
  InstagramIcon,
  LinkedinIcon,
  MailIcon,
  MapPinIcon,
  MountainIcon,
  TwitterIcon,
} from "./Icons";

const social = [
  { label: "Facebook", Icon: FacebookIcon },
  { label: "Instagram", Icon: InstagramIcon },
  { label: "Twitter", Icon: TwitterIcon },
  { label: "LinkedIn", Icon: LinkedinIcon },
];

export default function Footer() {
  return (
    <footer className="bg-brand-900 text-white/80">
      <div className="mx-auto grid max-w-7xl gap-10 px-5 py-14 sm:px-8 md:grid-cols-3">
        <div>
          <div className="flex items-center gap-2 font-display text-xl font-semibold text-white">
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-600">
              <MountainIcon width={18} height={18} />
            </span>
            Hunza Touristan
          </div>
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-white/70">
            Curated journeys through the Hunza Valley — from ancient Silk Road
            villages to the peaks of the Karakoram.
          </p>
        </div>

        <div>
          <h3 className="text-sm font-semibold uppercase tracking-widest text-white">
            Explore
          </h3>
          <ul className="mt-4 space-y-2 text-sm">
            {[
              ["#places", "Popular Places"],
              ["#gallery", "Gallery"],
              ["#reviews", "Traveler Reviews"],
              ["#book", "Book a Trip"],
            ].map(([href, label]) => (
              <li key={href}>
                <a href={href} className="transition hover:text-white">
                  {label}
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="text-sm font-semibold uppercase tracking-widest text-white">
            Contact
          </h3>
          <ul className="mt-4 space-y-3 text-sm">
            <li className="flex items-center gap-2">
              <MapPinIcon width={16} height={16} /> Karimabad, Hunza, Gilgit-Baltistan
            </li>
            <li className="flex items-center gap-2">
              <MailIcon width={16} height={16} /> hello@hunzatouristan.com
            </li>
          </ul>
          <div className="mt-5 flex gap-3">
            {social.map(({ label, Icon }) => (
              <a
                key={label}
                href="#"
                aria-label={label}
                className="flex h-10 w-10 items-center justify-center rounded-full border border-white/20 transition hover:bg-white hover:text-brand-900"
              >
                <Icon width={18} height={18} />
              </a>
            ))}
          </div>
        </div>
      </div>
      <div className="border-t border-white/10">
        <p className="mx-auto max-w-7xl px-5 py-5 text-xs text-white/60 sm:px-8">
          © {new Date().getFullYear()} Hunza Touristan. Created by Razi Hunter. All rights
          reserved.
        </p>
      </div>
    </footer>
  );
}
