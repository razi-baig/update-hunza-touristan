import { getReviews } from "@/lib/reviews";
import { StarIcon } from "./Icons";
import ReviewForm from "./ReviewForm";

export default async function Reviews() {
  const rows = await getReviews();

  return (
    <section id="reviews" className="mx-auto max-w-7xl px-5 py-24 sm:px-8">
      <div className="max-w-2xl">
        <p className="section-eyebrow">Testimonials</p>
        <h2 className="section-title">What our travelers say</h2>
      </div>

      <div className="mt-12 grid gap-6 md:grid-cols-3">
        {rows.map((r) => (
          <figure
            key={r.id}
            className="flex flex-col rounded-2xl border border-slate-200 bg-white p-7 shadow-sm"
          >
            <div className="flex gap-0.5 text-accent" aria-label={`${r.rating} out of 5 stars`}>
              {[1, 2, 3, 4, 5].map((n) => (
                <StarIcon key={n} filled={n <= r.rating} width={18} height={18} />
              ))}
            </div>
            <blockquote className="mt-4 flex-1 text-sm leading-relaxed text-slate-700">
              “{r.comment}”
            </blockquote>
            <figcaption className="mt-6 flex items-center gap-3">
              <span className="flex h-11 w-11 items-center justify-center rounded-full bg-brand-100 font-semibold text-brand-700">
                {r.name.charAt(0).toUpperCase()}
              </span>
              <span>
                <span className="block text-sm font-semibold">{r.name}</span>
                {r.location && (
                  <span className="block text-xs text-slate-500">{r.location}</span>
                )}
              </span>
            </figcaption>
          </figure>
        ))}
      </div>

      <ReviewForm />
    </section>
  );
}
