import { ArrowRightIcon } from "./Icons";
import { highlights, images } from "@/lib/data";

export default function Hero() {
  return (
    <>
      <section id="home" className="relative isolate flex min-h-[100svh] items-center">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={images.hero}
          alt="Hunza Valley with green terraces and snow-capped peaks"
          className="absolute inset-0 -z-20 h-full w-full object-cover"
          fetchPriority="high"
        />
        <div className="absolute inset-0 -z-10 bg-gradient-to-b from-brand-900/70 via-brand-900/40 to-brand-900/80" />

        <div className="mx-auto w-full max-w-7xl px-5 pb-24 pt-32 sm:px-8">
          <div className="max-w-3xl animate-fade-up">
            <p className="inline-flex items-center gap-2 rounded-full border border-white/30 bg-white/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.2em] text-white backdrop-blur">
              Gilgit-Baltistan · Pakistan
            </p>
            <h1 className="mt-6 font-display text-5xl font-semibold leading-[1.05] text-white sm:text-6xl md:text-7xl">
              Discover the hidden paradise of Hunza
            </h1>
            <p className="mt-6 max-w-2xl text-base leading-relaxed text-white/85 sm:text-lg">
              A mountainous valley on the banks of the Hunza River, bordering Ishkoman,
              Shigar, Afghanistan&apos;s Wakhan Corridor and China&apos;s Xinjiang region.
              Ancient forts, turquoise lakes and Karakoram giants await.
            </p>
            <div className="mt-9 flex flex-wrap gap-4">
              <a href="#book" className="btn-primary !bg-accent !px-8 !py-3.5 hover:!bg-amber-600">
                Book Your Trip <ArrowRightIcon width={18} height={18} />
              </a>
              <a href="#places" className="btn-ghost !px-8 !py-3.5">
                Explore Places
              </a>
            </div>
          </div>
        </div>
      </section>

      <section aria-label="Hunza at a glance" className="relative z-10 -mt-14 px-5 sm:px-8">
        <dl className="mx-auto grid max-w-5xl grid-cols-2 gap-px overflow-hidden rounded-2xl bg-slate-200 shadow-xl shadow-brand-900/10 md:grid-cols-4">
          {highlights.map((h) => (
            <div key={h.label} className="bg-white px-6 py-6 text-center">
              <dt className="sr-only">{h.label}</dt>
              <dd className="font-display text-2xl font-semibold text-brand-700 sm:text-3xl">
                {h.value}
              </dd>
              <p className="mt-1 text-xs text-slate-500 sm:text-sm">{h.label}</p>
            </div>
          ))}
        </dl>
      </section>
    </>
  );
}
