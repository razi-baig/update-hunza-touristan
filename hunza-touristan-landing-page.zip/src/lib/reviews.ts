import { desc } from "drizzle-orm";
import { db } from "@/db";
import { reviews } from "@/db/schema";
import { seedReviews } from "./data";

export async function getReviews() {
  try {
    let rows = await db.select().from(reviews).orderBy(desc(reviews.createdAt)).limit(12);
    if (rows.length === 0) {
      await db.insert(reviews).values(seedReviews);
      rows = await db.select().from(reviews).orderBy(desc(reviews.createdAt)).limit(12);
    }
    return rows;
  } catch (err) {
    console.error("Failed to load reviews", err);
    return [];
  }
}
