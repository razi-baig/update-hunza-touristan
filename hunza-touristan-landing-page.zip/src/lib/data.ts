const img = (id: number, w = 1200, h = 800) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=${w}&h=${h}`;

export const images = {
  hero: img(15916728, 1920, 1080),
  night: img(15817300, 1920, 1000),
  booking: img(35405084, 1000, 1200),
};

export type Place = {
  id: string;
  name: string;
  tag: string;
  image: string;
  description: string;
};

export const places: Place[] = [
  {
    id: "karimabad",
    name: "Hon Karimabad",
    tag: "Viewpoint",
    image: img(28319618),
    description:
      "Hon Pass (4,200 m), on a steep ridge above Ultar, offers magnificent views of the Hunza valley and the Hispar, Spantik, Sost and Rakaposhi–Haramosh ranges, with an aerial perspective over the valley's majestic mountains.",
  },
  {
    id: "altit-mominabad",
    name: "Altit & Mominabad",
    tag: "Scenery",
    image: img(26289081),
    description:
      "Mist drifts through the terraced villages of Altit and Mominabad after the rain, revealing one of the most photogenic views in the valley.",
  },
  {
    id: "ladyfinger",
    name: "Lady Finger Peak",
    tag: "Mountaineering",
    image: img(19442083),
    description:
      "Bublimotin, or Ladyfinger Peak, is a distinctive rock spire in the Batura Muztagh of the Karakoram. It rises sharply above the Hunza Valley and offers a 6,000 m rock climb and some notable paragliding.",
  },
  {
    id: "ganish",
    name: "Ganish Village",
    tag: "Heritage",
    image: img(26757921),
    description:
      "The oldest settlement on the ancient Silk Road in Hunza, Ganish — meaning “gold” in Burushaski — is home to ancient watch towers, traditional mosques and a reservoir. It lies 90 km (about 2.5 hours) from Gilgit.",
  },
  {
    id: "aliabad",
    name: "Aliabad",
    tag: "Town",
    image: img(15916726),
    description:
      "The administrative and commercial centre of Hunza District in Gilgit–Baltistan, and a convenient base for exploring the valley.",
  },
];

export type GalleryItem = {
  title: string;
  season: string;
  image: string;
  description: string;
};

export const gallery: GalleryItem[] = [
  {
    title: "Attabad Lake",
    season: "Gojal",
    image: img(35302565),
    description:
      "Created in January 2010 by a major landslide in Attabad, this turquoise lake lies in the Gojal region of Hunza Valley.",
  },
  {
    title: "Passu Cones",
    season: "Karakoram Highway",
    image: img(27355461),
    description:
      "A small village near Gulmit, Gojal, set along the Karakoram Highway beneath the iconic Passu Cones.",
  },
  {
    title: "Autumn in Altit",
    season: "Autumn",
    image: img(35171324),
    description:
      "Autumn brings vibrant colour to the Hunza Valley as orchards turn gold and crimson.",
  },
  {
    title: "Hunza in Winter",
    season: "Winter",
    image: img(15556464),
    description:
      "Snow blankets the valley as temperatures drop below zero through the winter season.",
  },
  {
    title: "Spring Blossom",
    season: "Spring",
    image: img(30897758),
    description:
      "Blossom season runs from the second week of March to the end of April, painting the valley white, pink and green.",
  },
  {
    title: "Summer in Hunza",
    season: "Summer",
    image: img(15916728),
    description:
      "Summers are moderate, peaking near 31 °C in July–August in Central Hunza. Upper Hunza (Gojal) stays much cooler.",
  },
];

export const highlights = [
  { value: "2,500 m", label: "Elevation of Karimabad" },
  { value: "6,000 m", label: "Climbing on Ladyfinger Peak" },
  { value: "90 km", label: "From Gilgit to Ganish" },
  { value: "4 seasons", label: "Each with its own beauty" },
];

export const seedReviews = [
  {
    name: "Sara Khan",
    location: "Lahore, Pakistan",
    rating: 5,
    comment:
      "Our spring trip during the cherry blossom season was unforgettable. The itinerary was well paced and the local guides were warm and knowledgeable.",
  },
  {
    name: "David Miller",
    location: "Manchester, UK",
    rating: 5,
    comment:
      "Altit, Karimabad and Attabad Lake in one week. Every transfer was on time and the hospitality along the Karakoram Highway was exceptional.",
  },
  {
    name: "Beilie Zhang",
    location: "Shanghai, China",
    rating: 4,
    comment:
      "Stunning scenery and a very smooth booking process. I'd suggest staying a little longer in Passu — there is so much to see.",
  },
];
