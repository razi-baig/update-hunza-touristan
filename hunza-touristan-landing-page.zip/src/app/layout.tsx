import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Hunza Touristan | Explore the Hidden Paradise of Hunza Valley",
  description:
    "Plan your journey to Hunza Valley in Gilgit-Baltistan, Pakistan. Discover Karimabad, Attabad Lake, Passu, Ganish and more with Hunza Touristan.",
  openGraph: {
    title: "Hunza Touristan",
    description: "Explore the hidden paradise of Hunza Valley, Pakistan.",
    type: "website",
  },
};

export const viewport: Viewport = {
  themeColor: "#0b3d32",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
