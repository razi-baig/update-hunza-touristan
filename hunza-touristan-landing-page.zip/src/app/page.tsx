import BookingForm from "@/components/BookingForm";
import Footer from "@/components/Footer";
import Gallery from "@/components/Gallery";
import Header from "@/components/Header";
import Hero from "@/components/Hero";
import Places from "@/components/Places";
import Reviews from "@/components/Reviews";
import ScrollTop from "@/components/ScrollTop";

export const dynamic = "force-dynamic";

export default function Home() {
  return (
    <>
      <Header />
      <main>
        <Hero />
        <Places />
        <Gallery />
        <Reviews />
        <BookingForm />
      </main>
      <Footer />
      <ScrollTop />
    </>
  );
}
