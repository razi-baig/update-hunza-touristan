import { NextResponse } from "next/server";
import { db } from "@/db";
import { bookings } from "@/db/schema";

export const dynamic = "force-dynamic";

const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function POST(request: Request) {
  let body: Record<string, unknown>;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body." }, { status: 400 });
  }

  const str = (v: unknown) => (typeof v === "string" ? v.trim() : "");
  const name = str(body.name);
  const email = str(body.email);
  const phone = str(body.phone);
  const destination = str(body.destination);
  const travelDate = str(body.travelDate);
  const message = str(body.message);
  const travelers = Number(body.travelers);

  const errors: Record<string, string> = {};
  if (name.length < 2 || name.length > 120) errors.name = "Please enter your full name.";
  if (!emailRe.test(email) || email.length > 200) errors.email = "Please enter a valid email address.";
  if (phone.replace(/[^\d]/g, "").length < 7 || phone.length > 40)
    errors.phone = "Please enter a valid phone number.";
  if (!destination || destination.length > 120) errors.destination = "Please choose a destination.";
  if (!Number.isInteger(travelers) || travelers < 1 || travelers > 50)
    errors.travelers = "Travelers must be between 1 and 50.";
  if (travelDate && !/^\d{4}-\d{2}-\d{2}$/.test(travelDate))
    errors.travelDate = "Please choose a valid date.";
  if (message.length > 2000) errors.message = "Message is too long.";

  if (Object.keys(errors).length > 0) {
    return NextResponse.json({ error: "Please check the highlighted fields.", errors }, { status: 400 });
  }

  try {
    const [row] = await db
      .insert(bookings)
      .values({
        name,
        email,
        phone,
        destination,
        travelers,
        travelDate: travelDate || null,
        message: message || null,
      })
      .returning({ id: bookings.id });
    return NextResponse.json({ ok: true, id: row.id }, { status: 201 });
  } catch (err) {
    console.error("Booking insert failed", err);
    return NextResponse.json(
      { error: "We couldn't save your request. Please try again." },
      { status: 500 },
    );
  }
}
