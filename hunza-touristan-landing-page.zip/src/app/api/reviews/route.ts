import { NextResponse } from "next/server";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { reviews } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(reviews).orderBy(desc(reviews.createdAt)).limit(50);
  return NextResponse.json(rows);
}

export async function POST(request: Request) {
  let body: Record<string, unknown>;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body." }, { status: 400 });
  }

  const str = (v: unknown) => (typeof v === "string" ? v.trim() : "");
  const name = str(body.name);
  const location = str(body.location);
  const comment = str(body.comment);
  const rating = Number(body.rating);

  if (name.length < 2 || name.length > 80)
    return NextResponse.json({ error: "Please enter your name." }, { status: 400 });
  if (location.length > 80)
    return NextResponse.json({ error: "Location is too long." }, { status: 400 });
  if (!Number.isInteger(rating) || rating < 1 || rating > 5)
    return NextResponse.json({ error: "Please select a rating from 1 to 5." }, { status: 400 });
  if (comment.length < 10 || comment.length > 800)
    return NextResponse.json(
      { error: "Please write a review between 10 and 800 characters." },
      { status: 400 },
    );

  try {
    await db.insert(reviews).values({ name, location: location || null, rating, comment });
    return NextResponse.json({ ok: true }, { status: 201 });
  } catch (err) {
    console.error("Review insert failed", err);
    return NextResponse.json({ error: "We couldn't save your review." }, { status: 500 });
  }
}
